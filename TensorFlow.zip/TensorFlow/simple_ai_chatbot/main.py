import nltk 
from nltk.stem.lancaster import LancasterStemmer

stemmer =  LancasterStemmer()

import numpy as np
import tensorflow
from tensorflow import keras
#import tflearn
import json
import pickle
try:
    with open("data.pickel", "rb") as f:
        words, labels, docs_x, docs_y = pickle.load(f) ##needed toload because of the training[0] in creating model object
except: 
    words= [] #["hi", "how", "are", "you", "whats", "up".......]
    labels = [] #["greeting", "goodbye", "age"......]
    docs_x = [] #[["hi"], ["how", "are", "you"], ["whats", "up"].....]
    docs_y = [] #["greetings", "greetings"......., "goodbye", "goodbye".......]
    with open('intents.json') as f:
        data = json.load(f)

    for intent in data["intents"]:
        for pattern in intent["patterns"]:
            wrds = nltk.word_tokenize(pattern)  
            words.extend(wrds)
            docs_x.append(wrds)
            docs_y.append(intent["tag"])
        if intent["tag"] not in labels:
            labels.append(intent["tag"])

    words = [stemmer.stem(w.lower()) for w in words if w != "?"]
    words = sorted(list(set(words)))
    labels = sorted(labels)

    training = []
    output = []
    out_empty = [0 for _ in range(len(labels))] 

    #input(here training) = [0, 0, 1, 1, 0, ......] represent which words are prersent in the input from the words list
    #output = [1, 0, 0, 1, 0] reprtersent which tags we can use to answer (or) to which tags the input belogs to

    for x, doc in enumerate(docs_x):
        
        bag = [] # will tell us which words in words list are present in each scenetence means(here) each doc
        wrds = [stemmer.stem(w) for w in doc]
        for w in words:
            if w in wrds:
                bag.append(1)
            else:
                bag.append(0)
        output_row = out_empty[:]
        output_row[labels.index(docs_y[x])] = 1
        training.append(bag)
        output.append(output_row)

    training = np.array(training)
    output = np.array(output)
    with open("data.pickle", "wb") as f:
        pickle.dump((words, labels, docs_x, docs_y), f)

#tensorflow.reset_default_graph()
model = keras.Sequential()
model.add(keras.layers.Flatten(input_shape=(0, len(training[0]))))
model.add(keras.layers.Dense(8))
model.add(keras.layers.Dense(8))
model.add(keras.layers.Dense(output[0], activation = "softmax"))

model.compile(optimizer = "adam", loss = "sparse_categorical_crossentropy")
try:
    model.load("model.tflearn", "rb")
except:
    model.fit(training, output, batch_size = 5, epochs=1000, show_metric=True)
    model.save("model.tflearn")

def bag_of_words(s, words):
    
    input = [0 for _ in range(len(words))] #[0, 0, 0, ....] and not [[0], [0]......]
    s_words = [stemmer.stem(w.lower()) for w in words.split(" ")]
    for w in words:
        if w in s_words:
            input.append(1)
        else:
            input.append(0)
    return np.array(input)

def chat():
    print('Start talking with the bot.....')
    print("To exit just type quit")
    while True:
        inp = input("You:")
        if inp.lower() == "quit":
            break
        results = model.predict([bag_of_words(inp, words)])
        print(results)

'''
net = tflearn.input_data(shape = [None, len(training[0])]) #is none = batchsize ????
net = tflearn.fully_connected(net, 8)   
net = tflearn.fully_connected(net, 8)
net = tflearn.fully_connected(net, output[0], activation = "softmax")
net = tflearn.regression(net)
model = tflearn.DNN(net)
'''

chat()
